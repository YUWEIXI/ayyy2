#include "interface.h"

int main() {
    char buffer[10];
    ssize_t len = in(buffer, sizeof(buffer));
    // Four consecutive bytes of 'a' trigger crash
    int t = 0;
    for(int i=0;i<len;i++){
        t=t*10+1;
    }
    buffer[t] = 'a';
    out("Safe");
    return 0;
}
