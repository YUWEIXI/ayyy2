#include "interface.h"

int main() {
    char buffer[20];
    ssize_t len = in(buffer, sizeof(buffer));

    int index = 0;
    while(len > 1){
        len >>= 1;
        index++;
    }
    index = (1 << 4) / ((1 << 3) - index);
    //越界写入
    buffer[index] = 'p';
    out("Safe");
    return 0;
}
