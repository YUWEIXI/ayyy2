#include "interface.h"

int main() {
    char buffer[20];
    ssize_t len = in(buffer, sizeof(buffer));

    //越界写入
    buffer[len] = 'p';
    out("Safe");
    return 0;
}
