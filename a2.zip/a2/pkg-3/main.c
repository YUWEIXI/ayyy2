#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    printf("%d\n",len);
    int index = 0;
    while(len > 1){
        len >>= 1;
        index++;
    }
    printf("%d, %d\n",len, index);
    index = (1 << 4) / ((1 << 3) - index);
    //越界写入
    buffer[index] = 'p';
    out("Safe");
    return 0;
}
