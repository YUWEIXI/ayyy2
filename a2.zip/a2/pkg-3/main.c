#include "interface.h"

int main() {
    char buffer[512];
    ssize_t len = in(buffer, sizeof(buffer));

    // 输入长度恰好为 256 时越界写入
    if (len == 256)
        buffer[300] = 0; // 越界
    out("Safe");
    return 0;
}
