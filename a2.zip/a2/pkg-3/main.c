#include "interface.h"

int main() {
    char buffer[128];
    ssize_t len = in(buffer, sizeof(buffer));

    //越界写入
    buffer[len] = 0;
    out("Safe");
    return 0;
}
