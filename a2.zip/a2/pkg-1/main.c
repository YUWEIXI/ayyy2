#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    // 需连续 4 字节为 b 触发崩溃
    if (buffer[0] == 'b' && buffer[1] == 'b' && buffer[2] == 'b' && buffer[3] == 'b')
        abort();
    out("Safe");
    return 0;
}
