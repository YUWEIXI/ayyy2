#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    // 连续 4 字节为 a 触发崩溃
    int t = 0;
    for(int i=0;i<4;i++){
        t = t*10+(1 + buffer[i]-'a');
    }
    buffer[t] = 'a';
    out("Safe");
    return 0;
}
