#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    if (len < 4) abort();

    // 需连续 4 字节为 0xFF 触发崩溃
    if (buffer[0] == 0xFF && buffer[1] == 0xFF && buffer[2] == 0xFF && buffer[3] == 0xFF)
        abort();
    out("Safe");
    return 0;
}
