#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));

    // 当两字节和为 256 时崩溃
    (buffer[0] + buffer[1]) == 256 ? abort(): out("Safe");
    return 0;
}