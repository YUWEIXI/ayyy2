#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));

    (buffer[0] == buffer[1]) ? abort(): out("Safe");
    return 0;
}