#include "interface.h"

int main() {
    char buffer[10];
    ssize_t len = in(buffer, sizeof(buffer));

    buffer[len] = '\n';
    out("Safe");
    return 0;
}