#include "interface.h"

int main() {
    char buffer[10];
    ssize_t len = in(buffer, sizeof(buffer));
    int check = 0;
    // 仅当输入包含 'XX' 时触发耗时崩溃
    for (int i = 0; i < len; i++) {
        check += (buffer[i] == 'X') * 1000;
        buffer[check] = 'X';
    }

    out("Safe");
    return 0;
}