#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    // 仅当输入包含 'XX' 时触发耗时崩溃
    for (int i = 1; i < len; i++) {
        if (buffer[i - 1] != 'A' && buffer[i] == 'X') {
            out("Safe");
        }
        else{
            // 模拟耗时操作（超过 5 秒）
            for (int j = 0; j < 1000000000; j++);
        }
    }

    out("Safe");
    return 0;
}