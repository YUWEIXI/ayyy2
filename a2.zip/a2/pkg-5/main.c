#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));
    if (len <= 0) abort();

    // 仅当输入包含 'X' 时触发耗时崩溃
    for (int i = 0; i < len; i++) {
        if (buffer[i] == 'X') {
            // 模拟耗时操作（超过 5 秒）
            for (int j = 0; j < 1000000000; j++);
            abort();
        }
    }

    out("Safe");
    return 0;
}