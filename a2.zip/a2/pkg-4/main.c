#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));

    // 需输入序列为 "A"->"B"->"C" 触发崩溃
    static int state = 0;
    if (buffer[0] == 'A' && state == 0) state = 1;
    if (state == 1 && buffer[1] == 'B' && buffer[2] == 'C') out("abort");
    out("Safe");
    return 0;
}