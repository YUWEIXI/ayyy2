#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));

    // 需输入序列为 "A"->"B"->"C" 触发崩溃
    static int state = 0;
    if (buffer[0] == 'A' && state == 0) state = 1;
    else if (buffer[0] == 'B' && state == 1) state = 2;
    else if (buffer[0] == 'C' && state == 2) abort();
    out("Safe");
    return 0;
}