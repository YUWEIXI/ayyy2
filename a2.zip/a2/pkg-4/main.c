#include "interface.h"

int main() {
    char buffer[1024];
    ssize_t len = in(buffer, sizeof(buffer));

    int state = 0;
    state = state + len - 10;
    state = 10 / state;
    out("Safe");
    return 0;
}