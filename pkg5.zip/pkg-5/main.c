#include "interface.h"

int main() {
    char buffer[10];
    ssize_t len = in(buffer, sizeof(buffer));
    int check = 0;
    float temp = 0.5;
    // A time-consuming crash is triggered if the input contains 'XX'
    for (int i = 0; i < len; i++) {
        check += (buffer[i] == 'X');
    }
    temp += 1 / (2 - check);
    out("Safe");
    return 0;
}